"use client"

import { useState, useRef } from "react"
import Image from "next/image"
import { motion, useInView, AnimatePresence } from "framer-motion"
import { X, ArrowLeft, ArrowRight } from "lucide-react"

const projects = [
  {
    title: "Modern Kitchen",
    location: "Indianapolis",
    category: "Kitchen",
    image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=1200&q=80",
  },
  {
    title: "Luxury Master Bath",
    location: "Carmel",
    category: "Bathroom",
    image: "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=1200&q=80",
  },
  {
    title: "Entertainment Basement",
    location: "Fishers",
    category: "Basement",
    image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1200&q=80",
  },
  {
    title: "Outdoor Living Space",
    location: "Noblesville",
    category: "Outdoor",
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=80",
  },
  {
    title: "Complete Addition",
    location: "Westfield",
    category: "Addition",
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&q=80",
  },
  {
    title: "Contemporary Kitchen",
    location: "Zionsville",
    category: "Kitchen",
    image: "https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=1200&q=80",
  },
]

export function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null)
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  const openLightbox = (index: number) => setSelectedImage(index)
  const closeLightbox = () => setSelectedImage(null)
  const nextImage = () => setSelectedImage((prev) => (prev !== null ? (prev + 1) % projects.length : 0))
  const prevImage = () => setSelectedImage((prev) => (prev !== null ? (prev - 1 + projects.length) % projects.length : 0))

  return (
    <section id="gallery" ref={ref} className="py-32 md:py-40 bg-[#fafafa] relative overflow-hidden">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end md:justify-between gap-8 mb-20"
        >
          <div className="max-w-2xl">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-px bg-[#F80000]" />
              <span className="text-[11px] tracking-[0.3em] uppercase text-muted-foreground font-medium">
                Portfolio
              </span>
            </div>
            <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground leading-[1.1] tracking-tight">
              Recent <span className="italic text-[#F80000]">Projects</span>
            </h2>
          </div>
          <p className="text-muted-foreground max-w-md text-[15px] leading-relaxed md:text-right">
            Each project represents our commitment to excellence. Explore our portfolio of completed transformations across Indiana.
          </p>
        </motion.div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-12 gap-4">
          {projects.map((project, index) => {
            const isLarge = index === 0 || index === 3
            const colSpan = isLarge ? "col-span-12 md:col-span-8" : "col-span-12 md:col-span-4"
            const aspectRatio = isLarge ? "aspect-[16/10]" : "aspect-square"

            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 60 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ 
                  duration: 1, 
                  delay: 0.1 + index * 0.08,
                  ease: [0.16, 1, 0.3, 1] 
                }}
                className={colSpan}
              >
                <button
                  onClick={() => openLightbox(index)}
                  onMouseEnter={() => setHoveredIndex(index)}
                  onMouseLeave={() => setHoveredIndex(null)}
                  className={`group relative ${aspectRatio} w-full overflow-hidden bg-muted`}
                >
                  <Image
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    fill
                    className={`object-cover transition-all duration-700 ${
                      hoveredIndex !== null && hoveredIndex !== index 
                        ? "grayscale scale-100" 
                        : "grayscale-0 scale-105 group-hover:scale-100"
                    }`}
                  />
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/40 transition-all duration-500" />
                  
                  {/* Content */}
                  <div className="absolute inset-0 p-6 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <span className="text-[11px] tracking-[0.3em] uppercase text-[#F80000] font-medium mb-2">
                      {project.category}
                    </span>
                    <h3 className="font-serif text-2xl md:text-3xl text-white tracking-tight">
                      {project.title}
                    </h3>
                    <p className="text-white/70 text-sm mt-1">{project.location}, IN</p>
                  </div>

                  {/* Corner accent */}
                  <div className="absolute top-0 right-0 w-16 h-16 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-[#F80000]" />
                  </div>
                </button>
              </motion.div>
            )
          })}
        </div>

        {/* View All Button */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="text-center mt-16"
        >
          <button className="group inline-flex items-center gap-4 border border-foreground text-foreground px-10 py-5 text-sm tracking-[0.15em] uppercase font-medium hover:bg-foreground hover:text-background transition-all duration-300">
            View All Projects
            <svg 
              className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </button>
        </motion.div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-50 bg-foreground/95 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={closeLightbox}
          >
            <button
              onClick={closeLightbox}
              className="absolute top-6 right-6 w-12 h-12 flex items-center justify-center text-background/70 hover:text-background transition-colors z-10"
            >
              <X className="w-6 h-6" />
            </button>
            
            <button
              onClick={(e) => { e.stopPropagation(); prevImage(); }}
              className="absolute left-6 top-1/2 -translate-y-1/2 w-12 h-12 flex items-center justify-center text-background/70 hover:text-background transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            
            <button
              onClick={(e) => { e.stopPropagation(); nextImage(); }}
              className="absolute right-6 top-1/2 -translate-y-1/2 w-12 h-12 flex items-center justify-center text-background/70 hover:text-background transition-colors"
            >
              <ArrowRight className="w-6 h-6" />
            </button>

            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="relative w-full max-w-5xl aspect-[16/10]"
              onClick={(e) => e.stopPropagation()}
            >
              <Image
                src={projects[selectedImage].image || "/placeholder.svg"}
                alt={projects[selectedImage].title}
                fill
                className="object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-foreground/80 to-transparent">
                <span className="text-[11px] tracking-[0.3em] uppercase text-[#F80000] font-medium">
                  {projects[selectedImage].category}
                </span>
                <h3 className="font-serif text-2xl md:text-3xl text-background mt-2">
                  {projects[selectedImage].title}
                </h3>
                <p className="text-background/70 text-sm mt-1">
                  {projects[selectedImage].location}, IN
                </p>
              </div>
            </motion.div>

            {/* Navigation dots */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
              {projects.map((_, index) => (
                <button
                  key={index}
                  onClick={(e) => { e.stopPropagation(); setSelectedImage(index); }}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === selectedImage ? "bg-[#F80000] w-6" : "bg-background/30 hover:bg-background/50"
                  }`}
                />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  )
}
